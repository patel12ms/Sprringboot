package co.edureka.boot.beans.utils;

public class PasswordEncryptor {

	public PasswordEncryptor() {
		System.out.println("###--- PasswordEncryptor :: Constructor ---###");
	}

}
