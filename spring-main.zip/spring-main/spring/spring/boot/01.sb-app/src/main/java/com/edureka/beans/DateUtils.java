package com.edureka.beans;

import org.springframework.stereotype.Component;

@Component
public class DateUtils {

	public DateUtils() {
		 System.out.println("###--- DateUtils :: Constructor ---###");
	}

}
