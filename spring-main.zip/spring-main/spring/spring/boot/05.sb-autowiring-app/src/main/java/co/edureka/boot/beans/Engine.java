package co.edureka.boot.beans;

public interface Engine {
	public Integer start();
}
